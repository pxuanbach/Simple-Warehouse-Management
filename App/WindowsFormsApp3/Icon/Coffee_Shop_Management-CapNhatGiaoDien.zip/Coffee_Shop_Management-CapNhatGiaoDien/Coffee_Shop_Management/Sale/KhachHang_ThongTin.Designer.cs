﻿namespace Sale
{
    partial class KhachHang_ThongTin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KhachHang_ThongTin));
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gbKhachHang = new System.Windows.Forms.GroupBox();
            this.btxoa = new System.Windows.Forms.Button();
            this.btchinhsua = new System.Windows.Forms.Button();
            this.btinra = new System.Windows.Forms.Button();
            this.lbsinhnhat = new System.Windows.Forms.Label();
            this.lbmonkhoaikhau = new System.Windows.Forms.Label();
            this.lbsolantrongthang = new System.Windows.Forms.Label();
            this.lbsotientrongthang = new System.Windows.Forms.Label();
            this.lbtongsolan = new System.Windows.Forms.Label();
            this.lbtongsotien = new System.Windows.Forms.Label();
            this.lbmember = new System.Windows.Forms.Label();
            this.lbsdt = new System.Windows.Forms.Label();
            this.lbten = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbsodienthoai = new System.Windows.Forms.TextBox();
            this.bttimkiem = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.btthoat = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gbKhachHang.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.textBox16.Location = new System.Drawing.Point(0, 623);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(1248, 33);
            this.textBox16.TabIndex = 39;
            this.textBox16.TabStop = false;
            this.textBox16.Text = "Luôn mỉm cười, xin lỗi và cảm ơn!!!";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(250, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 38);
            this.label2.TabIndex = 40;
            this.label2.Text = "Khách hàng";
            // 
            // gbKhachHang
            // 
            this.gbKhachHang.AutoSize = true;
            this.gbKhachHang.Controls.Add(this.btxoa);
            this.gbKhachHang.Controls.Add(this.btchinhsua);
            this.gbKhachHang.Controls.Add(this.btinra);
            this.gbKhachHang.Controls.Add(this.lbsinhnhat);
            this.gbKhachHang.Controls.Add(this.lbmonkhoaikhau);
            this.gbKhachHang.Controls.Add(this.lbsolantrongthang);
            this.gbKhachHang.Controls.Add(this.lbsotientrongthang);
            this.gbKhachHang.Controls.Add(this.lbtongsolan);
            this.gbKhachHang.Controls.Add(this.lbtongsotien);
            this.gbKhachHang.Controls.Add(this.lbmember);
            this.gbKhachHang.Controls.Add(this.lbsdt);
            this.gbKhachHang.Controls.Add(this.lbten);
            this.gbKhachHang.Controls.Add(this.label10);
            this.gbKhachHang.Controls.Add(this.label9);
            this.gbKhachHang.Controls.Add(this.label8);
            this.gbKhachHang.Controls.Add(this.label3);
            this.gbKhachHang.Controls.Add(this.label1);
            this.gbKhachHang.Controls.Add(this.label7);
            this.gbKhachHang.Controls.Add(this.label6);
            this.gbKhachHang.Controls.Add(this.label5);
            this.gbKhachHang.Controls.Add(this.label4);
            this.gbKhachHang.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbKhachHang.Location = new System.Drawing.Point(63, 84);
            this.gbKhachHang.Name = "gbKhachHang";
            this.gbKhachHang.Size = new System.Drawing.Size(567, 472);
            this.gbKhachHang.TabIndex = 3;
            this.gbKhachHang.TabStop = false;
            this.gbKhachHang.Text = "Thông tin";
            // 
            // btxoa
            // 
            this.btxoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btxoa.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxoa.Location = new System.Drawing.Point(326, 407);
            this.btxoa.Name = "btxoa";
            this.btxoa.Size = new System.Drawing.Size(103, 35);
            this.btxoa.TabIndex = 5;
            this.btxoa.Text = "Xóa";
            this.btxoa.UseVisualStyleBackColor = false;
            // 
            // btchinhsua
            // 
            this.btchinhsua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btchinhsua.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btchinhsua.Location = new System.Drawing.Point(194, 407);
            this.btchinhsua.Name = "btchinhsua";
            this.btchinhsua.Size = new System.Drawing.Size(126, 35);
            this.btchinhsua.TabIndex = 4;
            this.btchinhsua.Text = "Chỉnh sửa";
            this.btchinhsua.UseVisualStyleBackColor = false;
            // 
            // btinra
            // 
            this.btinra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btinra.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btinra.Location = new System.Drawing.Point(436, 407);
            this.btinra.Name = "btinra";
            this.btinra.Size = new System.Drawing.Size(103, 35);
            this.btinra.TabIndex = 6;
            this.btinra.Text = "In ra";
            this.btinra.UseVisualStyleBackColor = false;
            // 
            // lbsinhnhat
            // 
            this.lbsinhnhat.AutoSize = true;
            this.lbsinhnhat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbsinhnhat.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbsinhnhat.Location = new System.Drawing.Point(220, 324);
            this.lbsinhnhat.Name = "lbsinhnhat";
            this.lbsinhnhat.Size = new System.Drawing.Size(102, 24);
            this.lbsinhnhat.TabIndex = 42;
            this.lbsinhnhat.Text = "13/01/2001";
            // 
            // lbmonkhoaikhau
            // 
            this.lbmonkhoaikhau.AutoSize = true;
            this.lbmonkhoaikhau.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbmonkhoaikhau.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmonkhoaikhau.Location = new System.Drawing.Point(220, 288);
            this.lbmonkhoaikhau.Name = "lbmonkhoaikhau";
            this.lbmonkhoaikhau.Size = new System.Drawing.Size(129, 24);
            this.lbmonkhoaikhau.TabIndex = 42;
            this.lbmonkhoaikhau.Text = "Cà phê sữa đá";
            // 
            // lbsolantrongthang
            // 
            this.lbsolantrongthang.AutoSize = true;
            this.lbsolantrongthang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbsolantrongthang.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbsolantrongthang.Location = new System.Drawing.Point(220, 252);
            this.lbsolantrongthang.Name = "lbsolantrongthang";
            this.lbsolantrongthang.Size = new System.Drawing.Size(22, 24);
            this.lbsolantrongthang.TabIndex = 42;
            this.lbsolantrongthang.Text = "5";
            // 
            // lbsotientrongthang
            // 
            this.lbsotientrongthang.AutoSize = true;
            this.lbsotientrongthang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbsotientrongthang.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbsotientrongthang.Location = new System.Drawing.Point(220, 216);
            this.lbsotientrongthang.Name = "lbsotientrongthang";
            this.lbsotientrongthang.Size = new System.Drawing.Size(77, 24);
            this.lbsotientrongthang.TabIndex = 42;
            this.lbsotientrongthang.Text = "200.000";
            // 
            // lbtongsolan
            // 
            this.lbtongsolan.AutoSize = true;
            this.lbtongsolan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbtongsolan.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtongsolan.Location = new System.Drawing.Point(220, 180);
            this.lbtongsolan.Name = "lbtongsolan";
            this.lbtongsolan.Size = new System.Drawing.Size(42, 24);
            this.lbtongsolan.TabIndex = 42;
            this.lbtongsolan.Text = "100";
            // 
            // lbtongsotien
            // 
            this.lbtongsotien.AutoSize = true;
            this.lbtongsotien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbtongsotien.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtongsotien.Location = new System.Drawing.Point(220, 144);
            this.lbtongsotien.Name = "lbtongsotien";
            this.lbtongsotien.Size = new System.Drawing.Size(102, 24);
            this.lbtongsotien.TabIndex = 42;
            this.lbtongsotien.Text = "10.000.000";
            // 
            // lbmember
            // 
            this.lbmember.AutoSize = true;
            this.lbmember.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbmember.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmember.Location = new System.Drawing.Point(220, 108);
            this.lbmember.Name = "lbmember";
            this.lbmember.Size = new System.Drawing.Size(44, 24);
            this.lbmember.TabIndex = 42;
            this.lbmember.Text = "VIP";
            // 
            // lbsdt
            // 
            this.lbsdt.AutoSize = true;
            this.lbsdt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbsdt.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbsdt.Location = new System.Drawing.Point(220, 72);
            this.lbsdt.Name = "lbsdt";
            this.lbsdt.Size = new System.Drawing.Size(112, 24);
            this.lbsdt.TabIndex = 17;
            this.lbsdt.Text = "0965676841";
            // 
            // lbten
            // 
            this.lbten.AutoSize = true;
            this.lbten.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbten.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbten.Location = new System.Drawing.Point(220, 36);
            this.lbten.Name = "lbten";
            this.lbten.Size = new System.Drawing.Size(129, 24);
            this.lbten.TabIndex = 16;
            this.lbten.Text = "Lê Hoàng Phú";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label10.Location = new System.Drawing.Point(6, 324);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 23);
            this.label10.TabIndex = 15;
            this.label10.Text = "Sinh nhật";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label9.Location = new System.Drawing.Point(6, 288);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 23);
            this.label9.TabIndex = 14;
            this.label9.Text = "Món khoái khẩu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label8.Location = new System.Drawing.Point(6, 252);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 23);
            this.label8.TabIndex = 13;
            this.label8.Text = "Số lần trong tháng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label3.Location = new System.Drawing.Point(6, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 23);
            this.label3.TabIndex = 12;
            this.label3.Text = "Số tiền trong tháng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(6, 180);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 23);
            this.label1.TabIndex = 11;
            this.label1.Text = "Tổng số lần";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label7.Location = new System.Drawing.Point(6, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 23);
            this.label7.TabIndex = 10;
            this.label7.Text = "Tổng số tiền";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label6.Location = new System.Drawing.Point(6, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 23);
            this.label6.TabIndex = 9;
            this.label6.Text = "Member";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Location = new System.Drawing.Point(6, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tên";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.Location = new System.Drawing.Point(6, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "SĐT";
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.tbsodienthoai);
            this.groupBox1.Controls.Add(this.bttimkiem);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(734, 84);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(321, 177);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm khách hàng";
            // 
            // tbsodienthoai
            // 
            this.tbsodienthoai.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsodienthoai.Location = new System.Drawing.Point(84, 40);
            this.tbsodienthoai.Name = "tbsodienthoai";
            this.tbsodienthoai.Size = new System.Drawing.Size(189, 31);
            this.tbsodienthoai.TabIndex = 1;
            this.tbsodienthoai.Text = "0965676841";
            this.tbsodienthoai.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bttimkiem
            // 
            this.bttimkiem.AutoSize = true;
            this.bttimkiem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bttimkiem.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttimkiem.Location = new System.Drawing.Point(84, 108);
            this.bttimkiem.Name = "bttimkiem";
            this.bttimkiem.Size = new System.Drawing.Size(154, 39);
            this.bttimkiem.TabIndex = 2;
            this.bttimkiem.Text = "Tìm kiếm";
            this.bttimkiem.UseVisualStyleBackColor = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label28.Location = new System.Drawing.Point(15, 48);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 23);
            this.label28.TabIndex = 7;
            this.label28.Text = "SĐT";
            // 
            // btthoat
            // 
            this.btthoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btthoat.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthoat.Location = new System.Drawing.Point(1077, 571);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(103, 35);
            this.btthoat.TabIndex = 7;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Sale.Properties.Resources._2020_10_aaaaaaa10_16_21_14;
            this.pictureBox1.Location = new System.Drawing.Point(703, 300);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(376, 239);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            // 
            // KhachHang_ThongTin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(1248, 656);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbKhachHang);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox16);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "KhachHang_ThongTin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông tin khách hàng";
            this.Load += new System.EventHandler(this.KhachHang_ThongTin_Load);
            this.gbKhachHang.ResumeLayout(false);
            this.gbKhachHang.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbKhachHang;
        private System.Windows.Forms.Label lbten;
        private System.Windows.Forms.Label lbsdt;
        private System.Windows.Forms.Label lbsinhnhat;
        private System.Windows.Forms.Label lbmonkhoaikhau;
        private System.Windows.Forms.Label lbsolantrongthang;
        private System.Windows.Forms.Label lbsotientrongthang;
        private System.Windows.Forms.Label lbtongsolan;
        private System.Windows.Forms.Label lbtongsotien;
        private System.Windows.Forms.Label lbmember;
        private System.Windows.Forms.Button btinra;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbsodienthoai;
        private System.Windows.Forms.Button bttimkiem;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button btchinhsua;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btxoa;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}
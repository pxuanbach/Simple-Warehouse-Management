﻿namespace Sale
{
    partial class XemThongBao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(XemThongBao));
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.gbKhachHang = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btluu = new System.Windows.Forms.Button();
            this.btchinhsuathongbao = new System.Windows.Forms.Button();
            this.btinra = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.gbdanhsachmondahet = new System.Windows.Forms.GroupBox();
            this.chbdanhsachmondahet = new System.Windows.Forms.CheckedListBox();
            this.btchontatca = new System.Windows.Forms.Button();
            this.btluulai = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btthoat = new System.Windows.Forms.Button();
            this.gbKhachHang.SuspendLayout();
            this.gbdanhsachmondahet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.textBox16.Location = new System.Drawing.Point(0, 629);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(1166, 33);
            this.textBox16.TabIndex = 40;
            this.textBox16.TabStop = false;
            this.textBox16.Text = "Luôn mỉm cười, xin lỗi và cảm ơn!!!";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gbKhachHang
            // 
            this.gbKhachHang.AutoSize = true;
            this.gbKhachHang.Controls.Add(this.textBox1);
            this.gbKhachHang.Controls.Add(this.btluu);
            this.gbKhachHang.Controls.Add(this.btchinhsuathongbao);
            this.gbKhachHang.Controls.Add(this.btinra);
            this.gbKhachHang.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbKhachHang.Location = new System.Drawing.Point(55, 67);
            this.gbKhachHang.Name = "gbKhachHang";
            this.gbKhachHang.Size = new System.Drawing.Size(449, 489);
            this.gbKhachHang.TabIndex = 42;
            this.gbKhachHang.TabStop = false;
            this.gbKhachHang.Text = "Thông tin";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Peru;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(17, 30);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(406, 372);
            this.textBox1.TabIndex = 0;
            // 
            // btluu
            // 
            this.btluu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btluu.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btluu.Location = new System.Drawing.Point(189, 424);
            this.btluu.Name = "btluu";
            this.btluu.Size = new System.Drawing.Size(103, 35);
            this.btluu.TabIndex = 1;
            this.btluu.Text = "Lưu";
            this.btluu.UseVisualStyleBackColor = false;
            // 
            // btchinhsuathongbao
            // 
            this.btchinhsuathongbao.AutoSize = true;
            this.btchinhsuathongbao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btchinhsuathongbao.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btchinhsuathongbao.Location = new System.Drawing.Point(57, 424);
            this.btchinhsuathongbao.Name = "btchinhsuathongbao";
            this.btchinhsuathongbao.Size = new System.Drawing.Size(126, 35);
            this.btchinhsuathongbao.TabIndex = 2;
            this.btchinhsuathongbao.TabStop = false;
            this.btchinhsuathongbao.Text = "Chỉnh sửa";
            this.btchinhsuathongbao.UseVisualStyleBackColor = false;
            // 
            // btinra
            // 
            this.btinra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btinra.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btinra.Location = new System.Drawing.Point(299, 424);
            this.btinra.Name = "btinra";
            this.btinra.Size = new System.Drawing.Size(103, 35);
            this.btinra.TabIndex = 3;
            this.btinra.TabStop = false;
            this.btinra.Text = "In ra";
            this.btinra.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(170, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 39);
            this.label2.TabIndex = 43;
            this.label2.Text = "Thông báo";
            // 
            // gbdanhsachmondahet
            // 
            this.gbdanhsachmondahet.AutoSize = true;
            this.gbdanhsachmondahet.Controls.Add(this.chbdanhsachmondahet);
            this.gbdanhsachmondahet.Controls.Add(this.btchontatca);
            this.gbdanhsachmondahet.Controls.Add(this.btluulai);
            this.gbdanhsachmondahet.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbdanhsachmondahet.Location = new System.Drawing.Point(621, 67);
            this.gbdanhsachmondahet.Name = "gbdanhsachmondahet";
            this.gbdanhsachmondahet.Size = new System.Drawing.Size(434, 489);
            this.gbdanhsachmondahet.TabIndex = 44;
            this.gbdanhsachmondahet.TabStop = false;
            this.gbdanhsachmondahet.Text = "Danh sách món đã hết";
            // 
            // chbdanhsachmondahet
            // 
            this.chbdanhsachmondahet.BackColor = System.Drawing.Color.Peru;
            this.chbdanhsachmondahet.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbdanhsachmondahet.FormattingEnabled = true;
            this.chbdanhsachmondahet.Items.AddRange(new object[] {
            "Cà phê sữa đá",
            "Trà chanh",
            "Cà phê đen",
            "Cà phê sữa đá",
            "Trà chanh",
            "Cà phê đen",
            "Cà phê sữa đá",
            "Trà chanh",
            "Cà phê đen",
            "Cà phê sữa đá",
            "Trà chanh",
            "Cà phê đen",
            "Cà phê sữa đá",
            "Trà chanh",
            "Cà phê đen",
            "Cà phê sữa đá",
            "Trà chanh",
            "Cà phê đen",
            "Cà phê sữa đá",
            "Trà chanh",
            "Cà phê đen"});
            this.chbdanhsachmondahet.Location = new System.Drawing.Point(21, 30);
            this.chbdanhsachmondahet.Name = "chbdanhsachmondahet";
            this.chbdanhsachmondahet.Size = new System.Drawing.Size(397, 368);
            this.chbdanhsachmondahet.TabIndex = 4;
            // 
            // btchontatca
            // 
            this.btchontatca.AutoSize = true;
            this.btchontatca.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btchontatca.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btchontatca.Location = new System.Drawing.Point(164, 424);
            this.btchontatca.Name = "btchontatca";
            this.btchontatca.Size = new System.Drawing.Size(125, 35);
            this.btchontatca.TabIndex = 6;
            this.btchontatca.Text = "Chọn tất cả";
            this.btchontatca.UseVisualStyleBackColor = false;
            // 
            // btluulai
            // 
            this.btluulai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btluulai.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btluulai.Location = new System.Drawing.Point(315, 424);
            this.btluulai.Name = "btluulai";
            this.btluulai.Size = new System.Drawing.Size(103, 35);
            this.btluulai.TabIndex = 5;
            this.btluulai.TabStop = false;
            this.btluulai.Text = "Lưu";
            this.btluulai.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Sale.Properties.Resources._2020_10_aaaaaaa10_16_21_14;
            this.pictureBox1.Location = new System.Drawing.Point(1051, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(89, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 45;
            this.pictureBox1.TabStop = false;
            // 
            // btthoat
            // 
            this.btthoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btthoat.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthoat.Location = new System.Drawing.Point(952, 579);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(103, 35);
            this.btthoat.TabIndex = 7;
            this.btthoat.TabStop = false;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = false;
            // 
            // XemThongBao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(1166, 662);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.gbdanhsachmondahet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gbKhachHang);
            this.Controls.Add(this.textBox16);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "XemThongBao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xem thông báo";
            this.Load += new System.EventHandler(this.XemThongBao_Load);
            this.gbKhachHang.ResumeLayout(false);
            this.gbKhachHang.PerformLayout();
            this.gbdanhsachmondahet.ResumeLayout(false);
            this.gbdanhsachmondahet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.GroupBox gbKhachHang;
        private System.Windows.Forms.Button btluu;
        private System.Windows.Forms.Button btchinhsuathongbao;
        private System.Windows.Forms.Button btinra;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox gbdanhsachmondahet;
        private System.Windows.Forms.Button btchontatca;
        private System.Windows.Forms.Button btluulai;
        private System.Windows.Forms.CheckedListBox chbdanhsachmondahet;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btthoat;
    }
}
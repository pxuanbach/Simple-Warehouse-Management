﻿namespace Sale
{
    partial class KhachHang_ThongTin_ChinhSua
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KhachHang_ThongTin_ChinhSua));
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gbKhachHang = new System.Windows.Forms.GroupBox();
            this.dtpsinhnhat = new System.Windows.Forms.DateTimePicker();
            this.cbthanhvien = new System.Windows.Forms.ComboBox();
            this.cbmonkhoaikhau = new System.Windows.Forms.ComboBox();
            this.tbsolantrongthang = new System.Windows.Forms.TextBox();
            this.btthoat = new System.Windows.Forms.Button();
            this.tbsotientrongthang = new System.Windows.Forms.TextBox();
            this.tbtongsolan = new System.Windows.Forms.TextBox();
            this.tbtongsotien = new System.Windows.Forms.TextBox();
            this.tbsdt = new System.Windows.Forms.TextBox();
            this.tbten = new System.Windows.Forms.TextBox();
            this.btluulai = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btmacdinh = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gbKhachHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.textBox16.Location = new System.Drawing.Point(0, 623);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(1248, 33);
            this.textBox16.TabIndex = 39;
            this.textBox16.TabStop = false;
            this.textBox16.Text = "Luôn mỉm cười, xin lỗi và cảm ơn!!!";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(325, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 36);
            this.label2.TabIndex = 41;
            this.label2.Text = "Khách hàng";
            // 
            // gbKhachHang
            // 
            this.gbKhachHang.AutoSize = true;
            this.gbKhachHang.Controls.Add(this.dtpsinhnhat);
            this.gbKhachHang.Controls.Add(this.cbthanhvien);
            this.gbKhachHang.Controls.Add(this.cbmonkhoaikhau);
            this.gbKhachHang.Controls.Add(this.tbsolantrongthang);
            this.gbKhachHang.Controls.Add(this.btthoat);
            this.gbKhachHang.Controls.Add(this.tbsotientrongthang);
            this.gbKhachHang.Controls.Add(this.tbtongsolan);
            this.gbKhachHang.Controls.Add(this.tbtongsotien);
            this.gbKhachHang.Controls.Add(this.tbsdt);
            this.gbKhachHang.Controls.Add(this.tbten);
            this.gbKhachHang.Controls.Add(this.btluulai);
            this.gbKhachHang.Controls.Add(this.label10);
            this.gbKhachHang.Controls.Add(this.label9);
            this.gbKhachHang.Controls.Add(this.label8);
            this.gbKhachHang.Controls.Add(this.label3);
            this.gbKhachHang.Controls.Add(this.label1);
            this.gbKhachHang.Controls.Add(this.label7);
            this.gbKhachHang.Controls.Add(this.label6);
            this.gbKhachHang.Controls.Add(this.label5);
            this.gbKhachHang.Controls.Add(this.label4);
            this.gbKhachHang.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbKhachHang.Location = new System.Drawing.Point(76, 81);
            this.gbKhachHang.Name = "gbKhachHang";
            this.gbKhachHang.Size = new System.Drawing.Size(673, 459);
            this.gbKhachHang.TabIndex = 42;
            this.gbKhachHang.TabStop = false;
            this.gbKhachHang.Text = "Thông tin";
            // 
            // dtpsinhnhat
            // 
            this.dtpsinhnhat.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpsinhnhat.Location = new System.Drawing.Point(214, 316);
            this.dtpsinhnhat.Name = "dtpsinhnhat";
            this.dtpsinhnhat.Size = new System.Drawing.Size(426, 31);
            this.dtpsinhnhat.TabIndex = 8;
            // 
            // cbthanhvien
            // 
            this.cbthanhvien.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbthanhvien.FormattingEnabled = true;
            this.cbthanhvien.Items.AddRange(new object[] {
            "Bình thường",
            "Thường xuyên",
            "VIP"});
            this.cbthanhvien.Location = new System.Drawing.Point(214, 100);
            this.cbthanhvien.Name = "cbthanhvien";
            this.cbthanhvien.Size = new System.Drawing.Size(426, 32);
            this.cbthanhvien.TabIndex = 2;
            this.cbthanhvien.Text = "VIP";
            // 
            // cbmonkhoaikhau
            // 
            this.cbmonkhoaikhau.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbmonkhoaikhau.FormattingEnabled = true;
            this.cbmonkhoaikhau.Items.AddRange(new object[] {
            "Cà phê sữa đá",
            "Trà chanh"});
            this.cbmonkhoaikhau.Location = new System.Drawing.Point(214, 281);
            this.cbmonkhoaikhau.Name = "cbmonkhoaikhau";
            this.cbmonkhoaikhau.Size = new System.Drawing.Size(426, 32);
            this.cbmonkhoaikhau.TabIndex = 7;
            this.cbmonkhoaikhau.Text = "Cà phê sữa đá";
            // 
            // tbsolantrongthang
            // 
            this.tbsolantrongthang.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsolantrongthang.Location = new System.Drawing.Point(214, 244);
            this.tbsolantrongthang.Name = "tbsolantrongthang";
            this.tbsolantrongthang.Size = new System.Drawing.Size(426, 31);
            this.tbsolantrongthang.TabIndex = 6;
            this.tbsolantrongthang.Text = "5";
            // 
            // btthoat
            // 
            this.btthoat.AutoSize = true;
            this.btthoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btthoat.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthoat.Location = new System.Drawing.Point(343, 390);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(154, 39);
            this.btthoat.TabIndex = 10;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = false;
            // 
            // tbsotientrongthang
            // 
            this.tbsotientrongthang.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsotientrongthang.Location = new System.Drawing.Point(214, 208);
            this.tbsotientrongthang.Name = "tbsotientrongthang";
            this.tbsotientrongthang.Size = new System.Drawing.Size(426, 31);
            this.tbsotientrongthang.TabIndex = 5;
            this.tbsotientrongthang.Text = "200.000";
            // 
            // tbtongsolan
            // 
            this.tbtongsolan.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbtongsolan.Location = new System.Drawing.Point(214, 172);
            this.tbtongsolan.Name = "tbtongsolan";
            this.tbtongsolan.Size = new System.Drawing.Size(426, 31);
            this.tbtongsolan.TabIndex = 4;
            this.tbtongsolan.Text = "100";
            // 
            // tbtongsotien
            // 
            this.tbtongsotien.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbtongsotien.Location = new System.Drawing.Point(214, 136);
            this.tbtongsotien.Name = "tbtongsotien";
            this.tbtongsotien.Size = new System.Drawing.Size(426, 31);
            this.tbtongsotien.TabIndex = 3;
            this.tbtongsotien.Text = "10.000.000";
            // 
            // tbsdt
            // 
            this.tbsdt.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsdt.Location = new System.Drawing.Point(214, 64);
            this.tbsdt.Name = "tbsdt";
            this.tbsdt.Size = new System.Drawing.Size(426, 31);
            this.tbsdt.TabIndex = 1;
            this.tbsdt.Text = "0965676841";
            // 
            // tbten
            // 
            this.tbten.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbten.Location = new System.Drawing.Point(214, 28);
            this.tbten.Name = "tbten";
            this.tbten.Size = new System.Drawing.Size(426, 31);
            this.tbten.TabIndex = 0;
            this.tbten.Text = "Lê Hoàng Phú";
            // 
            // btluulai
            // 
            this.btluulai.AutoSize = true;
            this.btluulai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btluulai.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btluulai.Location = new System.Drawing.Point(138, 390);
            this.btluulai.Name = "btluulai";
            this.btluulai.Size = new System.Drawing.Size(154, 39);
            this.btluulai.TabIndex = 9;
            this.btluulai.Text = "Lưu ";
            this.btluulai.UseVisualStyleBackColor = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label10.Location = new System.Drawing.Point(108, 324);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 23);
            this.label10.TabIndex = 15;
            this.label10.Text = "Sinh nhật";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label9.Location = new System.Drawing.Point(53, 288);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 23);
            this.label9.TabIndex = 14;
            this.label9.Text = "Món khoái khẩu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label8.Location = new System.Drawing.Point(35, 252);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 23);
            this.label8.TabIndex = 13;
            this.label8.Text = "Số lần trong tháng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label3.Location = new System.Drawing.Point(29, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 23);
            this.label3.TabIndex = 12;
            this.label3.Text = "Số tiền trong tháng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(92, 180);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 23);
            this.label1.TabIndex = 11;
            this.label1.Text = "Tổng số lần";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label7.Location = new System.Drawing.Point(86, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 23);
            this.label7.TabIndex = 10;
            this.label7.Text = "Tổng số tiền";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label6.Location = new System.Drawing.Point(121, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 23);
            this.label6.TabIndex = 9;
            this.label6.Text = "Member";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Location = new System.Drawing.Point(160, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tên";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.Location = new System.Drawing.Point(154, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "SĐT";
            // 
            // btmacdinh
            // 
            this.btmacdinh.AutoSize = true;
            this.btmacdinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btmacdinh.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmacdinh.Location = new System.Drawing.Point(781, 91);
            this.btmacdinh.Name = "btmacdinh";
            this.btmacdinh.Size = new System.Drawing.Size(170, 39);
            this.btmacdinh.TabIndex = 45;
            this.btmacdinh.Text = "Mặc định";
            this.btmacdinh.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Sale.Properties.Resources._2020_10_aaaaaaa10_16_21_14;
            this.pictureBox1.Location = new System.Drawing.Point(781, 225);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(419, 315);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // KhachHang_ThongTin_ChinhSua
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(1248, 656);
            this.Controls.Add(this.btmacdinh);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.gbKhachHang);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox16);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "KhachHang_ThongTin_ChinhSua";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chình sửa thông tin khách hàng";
            this.Load += new System.EventHandler(this.KhachHang_ThongTin_ChinhSua_Load);
            this.gbKhachHang.ResumeLayout(false);
            this.gbKhachHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbKhachHang;
        private System.Windows.Forms.Button btluulai;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbtongsotien;
        private System.Windows.Forms.TextBox tbsdt;
        private System.Windows.Forms.TextBox tbten;
        private System.Windows.Forms.TextBox tbtongsolan;
        private System.Windows.Forms.TextBox tbsotientrongthang;
        private System.Windows.Forms.TextBox tbsolantrongthang;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.ComboBox cbthanhvien;
        private System.Windows.Forms.ComboBox cbmonkhoaikhau;
        private System.Windows.Forms.DateTimePicker dtpsinhnhat;
        private System.Windows.Forms.Button btmacdinh;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sale
{
    public partial class ThongTinTaiChinh : Form
    {
        public ThongTinTaiChinh()
        {
            InitializeComponent();
        }

        private void btinra_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace Sale
{
    partial class ThongTinTaiChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinTaiChinh));
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gbKhachHang = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btinrathongtin = new System.Windows.Forms.Button();
            this.gbbieudo = new System.Windows.Forms.GroupBox();
            this.tcbieudo = new System.Windows.Forms.TabControl();
            this.ttheothang = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.ttheoquy = new System.Windows.Forms.TabPage();
            this.btinrabieudo = new System.Windows.Forms.Button();
            this.btthoat = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gbKhachHang.SuspendLayout();
            this.gbbieudo.SuspendLayout();
            this.tcbieudo.SuspendLayout();
            this.ttheothang.SuspendLayout();
            this.ttheoquy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.textBox16.Location = new System.Drawing.Point(0, 652);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(1224, 33);
            this.textBox16.TabIndex = 40;
            this.textBox16.TabStop = false;
            this.textBox16.Text = "Luôn mỉm cười, xin lỗi và cảm ơn!!!";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(462, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(296, 38);
            this.label2.TabIndex = 41;
            this.label2.Text = "Thông tin tài chính";
            // 
            // gbKhachHang
            // 
            this.gbKhachHang.AutoSize = true;
            this.gbKhachHang.Controls.Add(this.textBox1);
            this.gbKhachHang.Controls.Add(this.btinrathongtin);
            this.gbKhachHang.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbKhachHang.Location = new System.Drawing.Point(63, 75);
            this.gbKhachHang.Name = "gbKhachHang";
            this.gbKhachHang.Size = new System.Drawing.Size(502, 523);
            this.gbKhachHang.TabIndex = 42;
            this.gbKhachHang.TabStop = false;
            this.gbKhachHang.Text = "Thông tin";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Peru;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(6, 30);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(490, 422);
            this.textBox1.TabIndex = 46;
            // 
            // btinrathongtin
            // 
            this.btinrathongtin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btinrathongtin.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btinrathongtin.Location = new System.Drawing.Point(377, 458);
            this.btinrathongtin.Name = "btinrathongtin";
            this.btinrathongtin.Size = new System.Drawing.Size(103, 35);
            this.btinrathongtin.TabIndex = 42;
            this.btinrathongtin.TabStop = false;
            this.btinrathongtin.Text = "In ra";
            this.btinrathongtin.UseVisualStyleBackColor = false;
            this.btinrathongtin.Click += new System.EventHandler(this.btinra_Click);
            // 
            // gbbieudo
            // 
            this.gbbieudo.AutoSize = true;
            this.gbbieudo.Controls.Add(this.tcbieudo);
            this.gbbieudo.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbbieudo.Location = new System.Drawing.Point(654, 75);
            this.gbbieudo.Name = "gbbieudo";
            this.gbbieudo.Size = new System.Drawing.Size(524, 523);
            this.gbbieudo.TabIndex = 43;
            this.gbbieudo.TabStop = false;
            this.gbbieudo.Text = "Biểu đồ";
            // 
            // tcbieudo
            // 
            this.tcbieudo.Controls.Add(this.ttheothang);
            this.tcbieudo.Controls.Add(this.ttheoquy);
            this.tcbieudo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcbieudo.Location = new System.Drawing.Point(3, 27);
            this.tcbieudo.Name = "tcbieudo";
            this.tcbieudo.SelectedIndex = 0;
            this.tcbieudo.Size = new System.Drawing.Size(518, 493);
            this.tcbieudo.TabIndex = 46;
            // 
            // ttheothang
            // 
            this.ttheothang.BackColor = System.Drawing.Color.Peru;
            this.ttheothang.Controls.Add(this.button1);
            this.ttheothang.Location = new System.Drawing.Point(4, 32);
            this.ttheothang.Name = "ttheothang";
            this.ttheothang.Padding = new System.Windows.Forms.Padding(3);
            this.ttheothang.Size = new System.Drawing.Size(510, 457);
            this.ttheothang.TabIndex = 0;
            this.ttheothang.Text = "Theo tháng";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(401, 398);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 35);
            this.button1.TabIndex = 44;
            this.button1.TabStop = false;
            this.button1.Text = "In ra";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // ttheoquy
            // 
            this.ttheoquy.BackColor = System.Drawing.Color.Peru;
            this.ttheoquy.Controls.Add(this.btinrabieudo);
            this.ttheoquy.Location = new System.Drawing.Point(4, 32);
            this.ttheoquy.Name = "ttheoquy";
            this.ttheoquy.Padding = new System.Windows.Forms.Padding(3);
            this.ttheoquy.Size = new System.Drawing.Size(510, 457);
            this.ttheoquy.TabIndex = 1;
            this.ttheoquy.Text = "Theo quý";
            // 
            // btinrabieudo
            // 
            this.btinrabieudo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btinrabieudo.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btinrabieudo.Location = new System.Drawing.Point(401, 399);
            this.btinrabieudo.Name = "btinrabieudo";
            this.btinrabieudo.Size = new System.Drawing.Size(103, 35);
            this.btinrabieudo.TabIndex = 45;
            this.btinrabieudo.TabStop = false;
            this.btinrabieudo.Text = "In ra";
            this.btinrabieudo.UseVisualStyleBackColor = false;
            // 
            // btthoat
            // 
            this.btthoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btthoat.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthoat.Location = new System.Drawing.Point(1068, 611);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(103, 35);
            this.btthoat.TabIndex = 46;
            this.btthoat.TabStop = false;
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Sale.Properties.Resources._2020_10_aaaaaaa10_16_21_14;
            this.pictureBox1.Location = new System.Drawing.Point(1113, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(89, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            // 
            // ThongTinTaiChinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(1224, 685);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.gbbieudo);
            this.Controls.Add(this.gbKhachHang);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox16);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ThongTinTaiChinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông tin tài chính";
            this.gbKhachHang.ResumeLayout(false);
            this.gbKhachHang.PerformLayout();
            this.gbbieudo.ResumeLayout(false);
            this.tcbieudo.ResumeLayout(false);
            this.ttheothang.ResumeLayout(false);
            this.ttheoquy.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbKhachHang;
        private System.Windows.Forms.Button btinrathongtin;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox gbbieudo;
        private System.Windows.Forms.TabControl tcbieudo;
        private System.Windows.Forms.TabPage ttheothang;
        private System.Windows.Forms.TabPage ttheoquy;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btinrabieudo;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
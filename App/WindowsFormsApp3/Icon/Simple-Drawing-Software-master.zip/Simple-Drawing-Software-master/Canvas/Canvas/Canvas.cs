﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Canvas
{
    public partial class Canvas: UserControl
    {
        Bitmap m_bmpMain;
        Graphics m_gfxMain;
        Graphics m_gfxSelected;
        Graphics m_gfxTemplate;

        Pen m_TempPen;

        int m_iLastX;
        int m_iLastY;

        int m_iBrushSize = 10;

        public List<Bitmap> m_bmpLayers = new List<Bitmap>();
        public Canvas()
        {
            InitializeComponent();
            m_bmpMain = new Bitmap(this.Width, this.Height);
            m_gfxMain = Graphics.FromImage(m_bmpMain);
            m_gfxTemplate = Graphics.FromImage(m_bmpMain);

            m_gfxTemplate.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            m_gfxTemplate.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
            m_gfxMain.Clear(Color.White);

            m_TempPen = new Pen(Color.Black, m_iBrushSize);
            m_TempPen.StartCap = m_TempPen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
            Display.Image = m_bmpMain;
        }
        public void Tap(object sender, MouseEventArgs e)
        {
            m_iLastX = e.X;
            m_iLastY = e.Y;
            if (m_gfxSelected == null)
                return;

        }
        public void Draw(object sender, MouseEventArgs e) //Tạm bợ thôi : ^) khi nào xong tools thì bỏ
        {
            if (m_gfxSelected == null)
                return;

            if (e.Button != MouseButtons.Left)
                return;
            m_gfxSelected.DrawLine(m_TempPen, m_iLastX, m_iLastY, e.X, e.Y);
            Update(e);
        }
        public new void Update()
        {
            m_gfxMain.Clear(Color.Transparent);
            foreach (Bitmap bmpLayer in m_bmpLayers.AsEnumerable().Reverse())
            {
                m_gfxMain.DrawImage(bmpLayer, 0, 0);
            }
            Display.Image = m_bmpMain;
        }
        public void Update(MouseEventArgs e)
        {
            //Calculate the redrawing area
            int iBrushOffSet = Convert.ToInt32((double)m_iBrushSize / 2.0 + 0.5);
            int iTempX = Math.Min(m_iLastX, e.X) - iBrushOffSet;
            int iTempY = Math.Min(m_iLastY, e.Y) - iBrushOffSet;
            int iTempW = Math.Max(m_iLastX, e.X) - iTempX;
            int iTempH = Math.Max(m_iLastY, e.Y) - iTempY;
            Rectangle recTargetedRec = new Rectangle(iTempX, iTempY, iTempW + iBrushOffSet, iTempH + iBrushOffSet);
            //Erase the area for redraw                                     
            m_gfxMain.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
            m_gfxMain.FillRectangle(new SolidBrush(Color.Transparent), recTargetedRec);
            //Actual redrawing
            m_gfxMain.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
            foreach(Bitmap bmpLayer in m_bmpLayers.AsEnumerable().Reverse())
            {
                m_gfxMain.DrawImage(bmpLayer, recTargetedRec, recTargetedRec, GraphicsUnit.Pixel);
            }
            Display.Image = m_bmpMain;
            m_iLastX = e.X;
            m_iLastY = e.Y;
        }
        public Bitmap NewLayer(int iIndex = 0)
        {
            Bitmap bmpNewBitMap = new Bitmap(m_bmpMain.Width, m_bmpMain.Height);
            m_bmpLayers.Insert(iIndex, bmpNewBitMap);
            return bmpNewBitMap;
        }
        public void Select(Bitmap bmpTargetedBitMap)
        {
            if (m_gfxSelected != null)
            {
                m_gfxSelected.Dispose();
            }
            m_gfxSelected = Graphics.FromImage(bmpTargetedBitMap);
        }
        public void DisposeBitmap(Bitmap bmpTargetedBitMap)
        {
            m_bmpLayers.Remove(bmpTargetedBitMap);
        }

        private void TempClickForColor(object sender, EventArgs e) // :^) cái này là nhiệm vụ của tools
        {
            PictureBox picSender = (PictureBox)sender;
            m_TempPen.Color = picSender.BackColor;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Test
{
    public partial class ColorWheel : UserControl
    {
        public ColorWheel()
        {
            InitializeComponent();
            sourceColor = new Bitmap(pbColor.Image, new Size(pbColor.Width, pbColor.Height));
            mainColor = new Bitmap(pbColor.Image, new Size(pbColor.Width, pbColor.Height));
            grapColor = Graphics.FromImage(mainColor);
            grapColor.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;

            sourceSaturation = new Bitmap(pbSaturation.Image, new Size(pbSaturation.Width, pbSaturation.Height));
            mainSaturation = new Bitmap(pbSaturation.Image, new Size(pbSaturation.Width, pbSaturation.Height));
            grapSaturation = Graphics.FromImage(mainSaturation);
            grapSaturation.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
        }

        Bitmap sourceColor, mainColor;
        Graphics grapColor;

        Bitmap sourceSaturation, mainSaturation;
        Graphics grapSaturation;

        int xPreCursorColor = 0, yPreCursorColor = 0;
        int xPreCursorSaturation = 74, yPreCursorSaturation = 0;

        private void pbColor_MouseMove(object sender, MouseEventArgs e)
        {
            Point center = new Point(pbColor.Width / 2, pbColor.Height / 2);
            int radius = 70;

            if (isMove && e.X != center.X && e.Y != center.Y)
            {
                double x, y;

                if ((e.X < center.X && e.Y < center.Y) || (e.X < center.X && e.Y > center.Y))
                    x = center.X - Math.Sqrt(Math.Pow(radius, 2) / (1 + Math.Pow(e.Y - center.Y, 2) / Math.Pow(e.X - center.X, 2)));
                else
                    x = center.X + Math.Sqrt(Math.Pow(radius, 2) / (1 + Math.Pow(e.Y - center.Y, 2) / Math.Pow(e.X - center.X, 2)));

                y = center.Y + (x - center.X) * (e.Y - center.Y) / (e.X - center.X);
               
                if (mainColor.GetPixel((int)x, (int)y).A == 255)
                {
                    Rectangle delBox = new Rectangle(xPreCursorColor - 8, yPreCursorColor - 8, 16, 16);
                    grapColor.FillRectangle(new SolidBrush(Color.Transparent), delBox);
                    grapColor.DrawImage(sourceColor, delBox, delBox, GraphicsUnit.Pixel);

                    pbSaturation.BackColor = mainColor.GetPixel((int)x, (int)y);

                    if (isFirst)
                    {
                        pbFirstColor.BackColor = mainColor.GetPixel((int)x, (int)y);
                        ShowColor(xPreCursorSaturation, yPreCursorSaturation, pbFirstColor.BackColor);
                    }
                    else
                    {
                        pbSecondColor.BackColor = mainColor.GetPixel((int)x, (int)y);
                        ShowColor(xPreCursorSaturation, yPreCursorSaturation, pbSecondColor.BackColor);
                    }

                    grapColor.DrawEllipse(new Pen(Color.Black, 3), (int)x - 6, (int)y - 6, 12, 12);
                    grapColor.DrawEllipse(new Pen(Color.White, 2), (int)x - 5, (int)y - 5, 10, 10);
                    
                    pbColor.Image = mainColor;
                    xPreCursorColor = (int)x;
                    yPreCursorColor = (int)y;
                }
            }
        }
        
        private void pbSaturation_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMove)
            {
                int x, y;
        
                if (e.X > pbSaturation.Width - 1)
                    x = pbSaturation.Width - 1;
                else if (e.X < 0)
                    x = 0;
                else
                    x = e.X;
        
                if (e.Y > pbSaturation.Height - 1)
                    y = pbSaturation.Height - 1;
                else if (e.Y < 0)
                    y = 0;
                else
                    y = e.Y;


                ShowColor(x, y, pbSaturation.BackColor);

                Rectangle delBox = new Rectangle(xPreCursorSaturation - 8, yPreCursorSaturation - 8, 16, 16);
                grapSaturation.FillRectangle(new SolidBrush(Color.Transparent), delBox);
                grapSaturation.DrawImage(sourceSaturation, delBox, delBox, GraphicsUnit.Pixel);

                grapSaturation.DrawEllipse(new Pen(Color.Black, 3), x - 6, y - 6, 12, 12);
                grapSaturation.DrawEllipse(new Pen(Color.White, 2), x - 5, y - 5, 10, 10);

                xPreCursorSaturation = x;
                yPreCursorSaturation = y;

                pbSaturation.Image = mainSaturation;
            }
        }
        
        private void ShowColor(int x,int y,Color color)
        {
            double red = (color.R + (255 - color.R)
                * ((double)(pbSaturation.Width - 1 - x) / (pbSaturation.Width - 1)))
                * ((double)(pbSaturation.Height - 1 - y) / (pbSaturation.Height - 1));


            double green = (color.G + (255 - color.G)
                * ((double)(pbSaturation.Width - 1 - x) / (pbSaturation.Width - 1)))
                * ((double)(pbSaturation.Height - 1 - y) / (pbSaturation.Height - 1));

            double blue = (color.B + (255 - color.B)
                * ((double)(pbSaturation.Width - 1 - x) / (pbSaturation.Width - 1)))
                * ((double)(pbSaturation.Height - 1 - y) / (pbSaturation.Height - 1));

            if (isFirst)
                pbFirstColor.BackColor = Color.FromArgb((int)red, (int)green, (int)blue);
            else
                pbSecondColor.BackColor = Color.FromArgb((int)red, (int)green, (int)blue);
        }


        bool isMove = false;
        
        private void pb_MouseDown(object sender, MouseEventArgs e)
        {
            isMove = true;

            if ((PictureBox)sender == pbColor)
            {
                Rectangle delBox = new Rectangle(e.X - 7, e.Y - 7, 16, 16);
                grapColor.FillRectangle(new SolidBrush(Color.Transparent), delBox);
                grapColor.DrawImage(sourceColor, delBox, delBox, GraphicsUnit.Pixel);
                pbColor_MouseMove(sender, e);
            }
            else
            {
                Rectangle delBox = new Rectangle(e.X - 7, e.Y - 7, 16, 16);
                grapSaturation.FillRectangle(new SolidBrush(Color.Transparent), delBox);
                grapSaturation.DrawImage(sourceSaturation, delBox, delBox, GraphicsUnit.Pixel);
                pbSaturation_MouseMove(sender, e);
            }
        }
        
        private void pb_MouseUp(object sender, MouseEventArgs e)
        {
            isMove = false;
        }

        bool isFirst = true;

        private void pbFirstColor_Click(object sender, EventArgs e)
        {
            isFirst = true;
        }

        private void pbSecondColor_Click(object sender, EventArgs e)
        {
            isFirst = false;
        }


        public Color getFirstColor()
        {
            return pbFirstColor.BackColor;
        }

        private void txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
    }
}

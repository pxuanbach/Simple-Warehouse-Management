﻿namespace Test
{
    partial class ColorWheel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelColor = new System.Windows.Forms.Panel();
            this.pbFirstColor = new System.Windows.Forms.PictureBox();
            this.pbSecondColor = new System.Windows.Forms.PictureBox();
            this.pbSaturation = new System.Windows.Forms.PictureBox();
            this.pbColor = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.lbTitle = new System.Windows.Forms.Label();
            this.panelColor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFirstColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSecondColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSaturation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelColor
            // 
            this.panelColor.BackColor = System.Drawing.Color.Transparent;
            this.panelColor.Controls.Add(this.pbFirstColor);
            this.panelColor.Controls.Add(this.pbSecondColor);
            this.panelColor.Controls.Add(this.pbSaturation);
            this.panelColor.Controls.Add(this.pbColor);
            this.panelColor.Controls.Add(this.pictureBox1);
            this.panelColor.Location = new System.Drawing.Point(10, 35);
            this.panelColor.Name = "panelColor";
            this.panelColor.Size = new System.Drawing.Size(230, 230);
            this.panelColor.TabIndex = 17;
            // 
            // pbFirstColor
            // 
            this.pbFirstColor.BackColor = System.Drawing.Color.White;
            this.pbFirstColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFirstColor.Location = new System.Drawing.Point(11, 182);
            this.pbFirstColor.Name = "pbFirstColor";
            this.pbFirstColor.Size = new System.Drawing.Size(29, 20);
            this.pbFirstColor.TabIndex = 16;
            this.pbFirstColor.TabStop = false;
            this.pbFirstColor.Click += new System.EventHandler(this.pbFirstColor_Click);
            // 
            // pbSecondColor
            // 
            this.pbSecondColor.BackColor = System.Drawing.Color.White;
            this.pbSecondColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSecondColor.Location = new System.Drawing.Point(23, 192);
            this.pbSecondColor.Name = "pbSecondColor";
            this.pbSecondColor.Size = new System.Drawing.Size(29, 20);
            this.pbSecondColor.TabIndex = 2;
            this.pbSecondColor.TabStop = false;
            this.pbSecondColor.Click += new System.EventHandler(this.pbSecondColor_Click);
            // 
            // pbSaturation
            // 
            this.pbSaturation.BackColor = System.Drawing.Color.Transparent;
            this.pbSaturation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSaturation.Image = global::Test.Properties.Resources.map_hue;
            this.pbSaturation.Location = new System.Drawing.Point(77, 78);
            this.pbSaturation.Name = "pbSaturation";
            this.pbSaturation.Size = new System.Drawing.Size(75, 75);
            this.pbSaturation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSaturation.TabIndex = 10;
            this.pbSaturation.TabStop = false;
            this.pbSaturation.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pb_MouseDown);
            this.pbSaturation.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbSaturation_MouseMove);
            this.pbSaturation.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pb_MouseUp);
            // 
            // pbColor
            // 
            this.pbColor.BackColor = System.Drawing.Color.White;
            this.pbColor.Image = global::Test.Properties.Resources.icon_large;
            this.pbColor.Location = new System.Drawing.Point(9, 9);
            this.pbColor.Name = "pbColor";
            this.pbColor.Size = new System.Drawing.Size(210, 212);
            this.pbColor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbColor.TabIndex = 0;
            this.pbColor.TabStop = false;
            this.pbColor.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pb_MouseDown);
            this.pbColor.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbColor_MouseMove);
            this.pbColor.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pb_MouseUp);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Test.Properties.Resources.oie_png1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(230, 230);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // panelTitle
            // 
            this.panelTitle.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panelTitle.Controls.Add(this.lbTitle);
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(0, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(250, 25);
            this.panelTitle.TabIndex = 18;
            // 
            // lbTitle
            // 
            this.lbTitle.AutoSize = true;
            this.lbTitle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitle.Location = new System.Drawing.Point(14, 3);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(88, 19);
            this.lbTitle.TabIndex = 0;
            this.lbTitle.Text = "Color wheel";
            // 
            // ColorWheel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Controls.Add(this.panelColor);
            this.Controls.Add(this.panelTitle);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ColorWheel";
            this.Size = new System.Drawing.Size(250, 378);
            this.panelColor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbFirstColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSecondColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSaturation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelColor;
        private System.Windows.Forms.PictureBox pbFirstColor;
        private System.Windows.Forms.PictureBox pbSecondColor;
        private System.Windows.Forms.PictureBox pbSaturation;
        private System.Windows.Forms.PictureBox pbColor;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

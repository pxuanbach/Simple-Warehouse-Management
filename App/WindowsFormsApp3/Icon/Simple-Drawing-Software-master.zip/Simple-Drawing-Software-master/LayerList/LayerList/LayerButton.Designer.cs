﻿namespace LayerList
{
    partial class LayerButton
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LayerButton));
            this.ButtonName = new System.Windows.Forms.Label();
            this.Art = new System.Windows.Forms.PictureBox();
            this.CheckBox = new System.Windows.Forms.PictureBox();
            this.NameChangeTextBox = new System.Windows.Forms.TextBox();
            this.Base = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Art)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheckBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Base)).BeginInit();
            this.SuspendLayout();
            // 
            // ButtonName
            // 
            this.ButtonName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonName.AutoSize = true;
            this.ButtonName.BackColor = System.Drawing.Color.White;
            this.ButtonName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonName.Location = new System.Drawing.Point(92, 8);
            this.ButtonName.Name = "ButtonName";
            this.ButtonName.Size = new System.Drawing.Size(44, 19);
            this.ButtonName.TabIndex = 0;
            this.ButtonName.Text = "Layer";
            this.ButtonName.Click += new System.EventHandler(this.LayerButton_Click);
            this.ButtonName.DoubleClick += new System.EventHandler(this.StartChangeNameLabel);
            this.ButtonName.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Down);
            this.ButtonName.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Move);
            this.ButtonName.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Up);
            // 
            // Art
            // 
            this.Art.BackColor = System.Drawing.Color.Gray;
            this.Art.Location = new System.Drawing.Point(25, 5);
            this.Art.Name = "Art";
            this.Art.Size = new System.Drawing.Size(60, 35);
            this.Art.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Art.TabIndex = 1;
            this.Art.TabStop = false;
            this.Art.Click += new System.EventHandler(this.LayerButton_Click);
            this.Art.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Down);
            this.Art.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Move);
            this.Art.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Up);
            // 
            // CheckBox
            // 
            this.CheckBox.BackColor = System.Drawing.Color.White;
            this.CheckBox.ErrorImage = ((System.Drawing.Image)(resources.GetObject("CheckBox.ErrorImage")));
            this.CheckBox.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox.Image")));
            this.CheckBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("CheckBox.InitialImage")));
            this.CheckBox.Location = new System.Drawing.Point(5, 5);
            this.CheckBox.Name = "CheckBox";
            this.CheckBox.Size = new System.Drawing.Size(15, 15);
            this.CheckBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CheckBox.TabIndex = 2;
            this.CheckBox.TabStop = false;
            this.CheckBox.Click += new System.EventHandler(this.LayerButton_Click);
            this.CheckBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Down);
            this.CheckBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Move);
            this.CheckBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Up);
            // 
            // NameChangeTextBox
            // 
            this.NameChangeTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NameChangeTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameChangeTextBox.Location = new System.Drawing.Point(92, 5);
            this.NameChangeTextBox.Name = "NameChangeTextBox";
            this.NameChangeTextBox.Size = new System.Drawing.Size(83, 26);
            this.NameChangeTextBox.TabIndex = 3;
            this.NameChangeTextBox.Click += new System.EventHandler(this.LayerButton_Click);
            this.NameChangeTextBox.SizeChanged += new System.EventHandler(this.SizeChanged);
            this.NameChangeTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.EndChangeNameLabel);
            // 
            // Base
            // 
            this.Base.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Base.BackColor = System.Drawing.Color.White;
            this.Base.ErrorImage = ((System.Drawing.Image)(resources.GetObject("Base.ErrorImage")));
            this.Base.InitialImage = ((System.Drawing.Image)(resources.GetObject("Base.InitialImage")));
            this.Base.Location = new System.Drawing.Point(2, 2);
            this.Base.Name = "Base";
            this.Base.Size = new System.Drawing.Size(196, 41);
            this.Base.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Base.TabIndex = 4;
            this.Base.TabStop = false;
            this.Base.SizeChanged += new System.EventHandler(this.SizeChanged);
            this.Base.Click += new System.EventHandler(this.LayerButton_Click);
            this.Base.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Down);
            this.Base.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Move);
            this.Base.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Up);
            // 
            // LayerButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.Controls.Add(this.ButtonName);
            this.Controls.Add(this.NameChangeTextBox);
            this.Controls.Add(this.CheckBox);
            this.Controls.Add(this.Art);
            this.Controls.Add(this.Base);
            this.Name = "LayerButton";
            this.Size = new System.Drawing.Size(200, 45);
            this.Click += new System.EventHandler(this.LayerButton_Click);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Down);
            this.MouseLeave += new System.EventHandler(this.NameChangeTextBox_Leave);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Move);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LayerButton_Up);
            ((System.ComponentModel.ISupportInitialize)(this.Art)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheckBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Base)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ButtonName;
        private System.Windows.Forms.PictureBox Art;
        private System.Windows.Forms.PictureBox CheckBox;
        private System.Windows.Forms.TextBox NameChangeTextBox;
        private System.Windows.Forms.PictureBox Base;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LayerList
{
    public partial class LayerButton : UserControl
    {
        public Bitmap m_ConnectedBitMap;
        public LayerButtonEventHandler m_EventHandler = new LayerButtonEventHandler();

        public LayerButton()
        {
            InitializeComponent();
            NameChangeTextBox.Hide();
            CheckBox.Image = CheckBox.ErrorImage;
            ButtonName.MaximumSize = new Size(NameChangeTextBox.Size.Width, ButtonName.Size.Height - 2);
        }
        private void LayerButton_Move(object sender, MouseEventArgs e)
        {
            m_EventHandler.StartEventMouseMove(this, e);
        }
        private void LayerButton_Up(object sender, MouseEventArgs e)
        {
            m_EventHandler.StartEventMouseUp(this, e);
        }
        private void LayerButton_Down(object sender, MouseEventArgs e)
        {
            m_EventHandler.StartEventMouseDown(this, e);
        }
        private void LayerButton_Click(object sender, EventArgs e)
        {
            m_EventHandler.StartEventClick(this, e);
        }

        public void StartChangeNameLabel(object sender, EventArgs e)
        {
            Label Name = sender as Label;
            NameChangeTextBox.Text = Name.Text;
            Name.Hide();
            NameChangeTextBox.Show();
        }

        public void EndChangeNameLabel(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ButtonName.Text = NameChangeTextBox.Text;
                ButtonName.Show();
                NameChangeTextBox.Hide();
                NameChangeTextBox.Text = "";
            }
        }

        private void NameChangeTextBox_Leave(object sender, EventArgs e)
        {
            if (NameChangeTextBox.Text != "")
            {
                ButtonName.Text = NameChangeTextBox.Text;
            }
            ButtonName.Show();
            NameChangeTextBox.Hide();
            NameChangeTextBox.Text = "";
        }

        private void SizeChanged(object sender, EventArgs e)
        {
            ButtonName.MaximumSize = new Size(NameChangeTextBox.Size.Width, ButtonName.Size.Height);
        }
        public void Selected()
        {
            this.BackColor = Color.Blue;
            this.CheckBox.Image = CheckBox.InitialImage;
        }
        public void Unselected()
        {
            this.BackColor = Color.DarkGray;
            this.CheckBox.Image = CheckBox.ErrorImage;
        }
        public void DisposeBitmap()
        {
            m_ConnectedBitMap.Dispose();
        }
        public void AssignBitmap(Bitmap bmpTarget)
        {
            this.m_ConnectedBitMap = bmpTarget;
        }
        public void UpdateArt()
        {
            this.Art.SizeMode = PictureBoxSizeMode.Zoom;
            this.Art.Image = this.m_ConnectedBitMap;
        }
    }

    public class LayerButtonEventHandler
    {    
        public event EventHandler Button_MouseClick;
        public event MouseEventHandler Button_MouseDown;
        public event MouseEventHandler Button_MouseUp;
        public event MouseEventHandler Button_MouseMove;

        public void StartEventClick     (object sender, EventArgs      e)
        {
            Button_MouseClick(sender, e);
        }
        public void StartEventMouseMove (object sender, MouseEventArgs e)
        {
            Button_MouseMove(sender, e);
        }
        public void StartEventMouseDown (object sender, MouseEventArgs e)
        {
            Button_MouseDown(sender, e);
        }
        public void StartEventMouseUp   (object sender, MouseEventArgs e)
        {
            Button_MouseUp  (sender, e);
        }
    }
}

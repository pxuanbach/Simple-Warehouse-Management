﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LayerList
{
    public partial class LayerListPanel: UserControl
    {
        public static int iSpaceV = 10;
        LayerButton SelectedButton;

        List<LayerButton> LayerButtons = new List<LayerButton>();

        Canvas.Canvas m_cvsMainCanvas;
        public LayerListPanel()
        {
            InitializeComponent();
            Template.Hide();
        }

        public void AssignCanvas(Canvas.Canvas canvas)
        {
            m_cvsMainCanvas = canvas;
            m_cvsMainCanvas.MouseMove += UpdateAfterDraw;
        }

        public void AddLayer(object sender, EventArgs e)
        {
            if (m_cvsMainCanvas == null)
                return;

            LayerButton NewButton = new LayerButton();
            Bitmap bmpNewLayer;
            if (LayerButtons.Count == 0)
            {
                NewButton.Location = Template.Location;
                SelectedButton = NewButton;
                NewButton.Selected();
                LayerButtons.Add(NewButton);
                bmpNewLayer = m_cvsMainCanvas.NewLayer();
                m_cvsMainCanvas.Select(bmpNewLayer);
            }
            else
            {
                int iIndex = 0;
                for (; iIndex < LayerButtons.Count; iIndex++)
                {
                    if (LayerButtons[iIndex] == SelectedButton)
                    {
                        break;
                    }
                }
                NewButton.Location = new Point(LayerButtons[iIndex].Location.X, LayerButtons[iIndex].Location.Y);
                LayerButtons.Insert(iIndex, NewButton);
                bmpNewLayer = m_cvsMainCanvas.NewLayer(iIndex);
                for (int i = LayerButtons.Count - 1; i > iIndex; i--)
                {
                    LayerButtons[i].Location = new Point(LayerButtons[i].Location.X, LayerButtons[i].Location.Y + Template.Height + iSpaceV);
                }
            }
            panel2.Controls.Add(NewButton);
            NewButton.Anchor = Template.Anchor;
            NewButton.Size = Template.Size;
            NewButton.m_EventHandler.Button_MouseClick += SelectButton;
            NewButton.AssignBitmap(bmpNewLayer);
            NewButton.m_EventHandler.Button_MouseDown += this.ChangeDragDropFocus;
            NewButton.m_EventHandler.Button_MouseDown += EventDragAndDrop.Start;
            NewButton.m_EventHandler.Button_MouseMove += EventDragAndDrop.Drag;
            NewButton.m_EventHandler.Button_MouseUp += EventDragAndDrop.End;
        }

        public void DeleteLayer(object sender, EventArgs e)
        {
            if (m_cvsMainCanvas == null)
                return;

            int iIndex = 0;
            bool bIsFound = false;
            for (; iIndex < LayerButtons.Count; iIndex++)
            {
                if (LayerButtons[iIndex] == SelectedButton)
                {
                    bIsFound = true;
                    break;
                }
            }

            if (bIsFound)
            {
                for (int i = LayerButtons.Count - 1; i > iIndex; i--)
                {
                    LayerButtons[i].Location = LayerButtons[i - 1].Location;
                }
                LayerButtons.RemoveAt(iIndex);
                m_cvsMainCanvas.DisposeBitmap(SelectedButton.m_ConnectedBitMap);
                SelectedButton.DisposeBitmap();
                SelectedButton.Dispose();
                if (iIndex < LayerButtons.Count)
                {
                    SelectedButton = LayerButtons[iIndex];
                }
                else if (iIndex > 0)
                {
                    SelectedButton = LayerButtons[iIndex - 1];
                }
                else
                {
                    SelectedButton = null;
                }
            }

            if (SelectedButton != null)
            {
                SelectedButton.Selected();
                m_cvsMainCanvas.Select(SelectedButton.m_ConnectedBitMap);
            }

            m_cvsMainCanvas.Update();
        }

        public void SelectButton(object sender, EventArgs e)
        {
            SelectedButton.Unselected();
            SelectedButton = (LayerButton)sender;
            m_cvsMainCanvas.Select(SelectedButton.m_ConnectedBitMap);
            SelectedButton.Selected();
        }
        public void ChangeDragDropFocus(object sender, MouseEventArgs e)
        {
            LayerList.EventDragAndDrop.m_llpFocusingPanel = this;
        }
        public void SwapButtonAfterMoved(LayerButton movedButton)
        {
            if (LayerButtons.Count == 1)
            {
                movedButton.Location = Template.Location;
                return;
            }
            LayerButtons.Remove(movedButton);
            m_cvsMainCanvas.m_bmpLayers.Remove(movedButton.m_ConnectedBitMap);

            int iIndex;
            if (movedButton.Location.Y > LayerButtons[LayerButtons.Count - 1].Location.Y)
            {
                movedButton.Location = new Point(LayerButtons[LayerButtons.Count - 1].Location.X, LayerButtons[LayerButtons.Count - 1].Location.Y + Template.Height + iSpaceV);
                LayerButtons.Add(movedButton);
                m_cvsMainCanvas.m_bmpLayers.Add(movedButton.m_ConnectedBitMap);
            }
            else if (movedButton.Location.Y <= LayerButtons[0].Location.Y)
            {
                movedButton.Location = Template.Location;
                LayerButtons.Insert(0, movedButton);
                m_cvsMainCanvas.m_bmpLayers.Insert(0, movedButton.m_ConnectedBitMap);
            }
            else for (iIndex = 0; iIndex < LayerButtons.Count - 1; iIndex++)
                {
                    if (LayerButtons[iIndex].Location.Y < movedButton.Location.Y && LayerButtons[iIndex + 1].Location.Y >= movedButton.Location.Y)
                    {
                        LayerButtons.Insert(iIndex + 1, movedButton);
                        m_cvsMainCanvas.m_bmpLayers.Insert(iIndex + 1, movedButton.m_ConnectedBitMap);
                        movedButton.Location = LayerButtons[iIndex].Location;

                        break;
                    }
                }

            LayerButtons[0].Location = Template.Location;
            for (int i = 1; i < LayerButtons.Count; i++)
            {
                LayerButtons[i].Location = new Point(LayerButtons[i - 1].Location.X, LayerButtons[i - 1].Location.Y + Template.Height + iSpaceV);
            }
            m_cvsMainCanvas.Update();
        }
        public void UpdateAfterDraw(object sender, MouseEventArgs e)
        {
            if (SelectedButton != null)
            {
                SelectedButton.UpdateArt();
            }
        }
    }

    public static class EventDragAndDrop
    {
        public static LayerListPanel m_llpFocusingPanel;
        static bool m_bIsStartMoving = false;
        static int m_iX;
        static int m_iY;
        public static void Start(object sender, MouseEventArgs e)
        {
            m_iX = e.X;
            m_iY = e.Y;
            LayerButton layerButton = (LayerButton)sender;
            layerButton.BringToFront();
        }
        public static void Drag(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && (Math.Abs(e.X - m_iX) > LayerListPanel.iSpaceV * 3 || Math.Abs(e.Y - m_iY) > LayerListPanel.iSpaceV * 3))
            {
                m_bIsStartMoving = true;
            }
            if (m_bIsStartMoving)
            {
                LayerButton layerButton = (LayerButton)sender;
                layerButton.Location = new Point(layerButton.Location.X + (e.X - m_iX), layerButton.Location.Y + (e.Y - m_iY));
            }
        }
        public static void End(object sender, MouseEventArgs e)
        {
            if (m_bIsStartMoving)
            {
                m_bIsStartMoving = false;
                m_llpFocusingPanel.SwapButtonAfterMoved((LayerButton)sender);
            }
        }
    }
}

﻿namespace DrawingSoftware
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.ToolsandLayerAndCanvas = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.canvas1 = new Canvas.Canvas();
            this.LayerAndColorPanel = new System.Windows.Forms.SplitContainer();
            this.ColorPanel = new System.Windows.Forms.SplitContainer();
            this.colorWheel1 = new Test.ColorWheel();
            this.savedColor1 = new Test.SavedColor();
            this.layerListPanel1 = new LayerList.LayerListPanel();
            ((System.ComponentModel.ISupportInitialize)(this.ToolsandLayerAndCanvas)).BeginInit();
            this.ToolsandLayerAndCanvas.Panel2.SuspendLayout();
            this.ToolsandLayerAndCanvas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LayerAndColorPanel)).BeginInit();
            this.LayerAndColorPanel.Panel1.SuspendLayout();
            this.LayerAndColorPanel.Panel2.SuspendLayout();
            this.LayerAndColorPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColorPanel)).BeginInit();
            this.ColorPanel.Panel1.SuspendLayout();
            this.ColorPanel.Panel2.SuspendLayout();
            this.ColorPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1584, 30);
            this.panel2.TabIndex = 2;
            // 
            // ToolsandLayerAndCanvas
            // 
            this.ToolsandLayerAndCanvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ToolsandLayerAndCanvas.Location = new System.Drawing.Point(0, 30);
            this.ToolsandLayerAndCanvas.Name = "ToolsandLayerAndCanvas";
            // 
            // ToolsandLayerAndCanvas.Panel2
            // 
            this.ToolsandLayerAndCanvas.Panel2.Controls.Add(this.splitContainer2);
            this.ToolsandLayerAndCanvas.Size = new System.Drawing.Size(1584, 831);
            this.ToolsandLayerAndCanvas.SplitterDistance = 150;
            this.ToolsandLayerAndCanvas.TabIndex = 3;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.canvas1);
            this.splitContainer2.Panel1MinSize = 150;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.LayerAndColorPanel);
            this.splitContainer2.Panel2MinSize = 150;
            this.splitContainer2.Size = new System.Drawing.Size(1430, 831);
            this.splitContainer2.SplitterDistance = 1180;
            this.splitContainer2.TabIndex = 0;
            // 
            // canvas1
            // 
            this.canvas1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.canvas1.AutoScroll = true;
            this.canvas1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.canvas1.Location = new System.Drawing.Point(0, 0);
            this.canvas1.Name = "canvas1";
            this.canvas1.Size = new System.Drawing.Size(1180, 831);
            this.canvas1.TabIndex = 0;
            // 
            // LayerAndColorPanel
            // 
            this.LayerAndColorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LayerAndColorPanel.Location = new System.Drawing.Point(0, 0);
            this.LayerAndColorPanel.Name = "LayerAndColorPanel";
            this.LayerAndColorPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // LayerAndColorPanel.Panel1
            // 
            this.LayerAndColorPanel.Panel1.Controls.Add(this.ColorPanel);
            // 
            // LayerAndColorPanel.Panel2
            // 
            this.LayerAndColorPanel.Panel2.Controls.Add(this.layerListPanel1);
            this.LayerAndColorPanel.Size = new System.Drawing.Size(246, 831);
            this.LayerAndColorPanel.SplitterDistance = 399;
            this.LayerAndColorPanel.TabIndex = 1;
            // 
            // ColorPanel
            // 
            this.ColorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ColorPanel.Location = new System.Drawing.Point(0, 0);
            this.ColorPanel.Name = "ColorPanel";
            this.ColorPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // ColorPanel.Panel1
            // 
            this.ColorPanel.Panel1.Controls.Add(this.colorWheel1);
            // 
            // ColorPanel.Panel2
            // 
            this.ColorPanel.Panel2.Controls.Add(this.savedColor1);
            this.ColorPanel.Size = new System.Drawing.Size(246, 399);
            this.ColorPanel.SplitterDistance = 271;
            this.ColorPanel.TabIndex = 0;
            // 
            // colorWheel1
            // 
            this.colorWheel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.colorWheel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.colorWheel1.Location = new System.Drawing.Point(0, 0);
            this.colorWheel1.Margin = new System.Windows.Forms.Padding(2);
            this.colorWheel1.Name = "colorWheel1";
            this.colorWheel1.Size = new System.Drawing.Size(246, 271);
            this.colorWheel1.TabIndex = 0;
            // 
            // savedColor1
            // 
            this.savedColor1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.savedColor1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.savedColor1.Location = new System.Drawing.Point(0, 0);
            this.savedColor1.Name = "savedColor1";
            this.savedColor1.Size = new System.Drawing.Size(246, 124);
            this.savedColor1.TabIndex = 0;
            // 
            // layerListPanel1
            // 
            this.layerListPanel1.AutoScroll = true;
            this.layerListPanel1.BackColor = System.Drawing.Color.White;
            this.layerListPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layerListPanel1.Location = new System.Drawing.Point(0, 0);
            this.layerListPanel1.MinimumSize = new System.Drawing.Size(123, 0);
            this.layerListPanel1.Name = "layerListPanel1";
            this.layerListPanel1.Size = new System.Drawing.Size(246, 428);
            this.layerListPanel1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1584, 861);
            this.Controls.Add(this.ToolsandLayerAndCanvas);
            this.Controls.Add(this.panel2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ToolsandLayerAndCanvas.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ToolsandLayerAndCanvas)).EndInit();
            this.ToolsandLayerAndCanvas.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.LayerAndColorPanel.Panel1.ResumeLayout(false);
            this.LayerAndColorPanel.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LayerAndColorPanel)).EndInit();
            this.LayerAndColorPanel.ResumeLayout(false);
            this.ColorPanel.Panel1.ResumeLayout(false);
            this.ColorPanel.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ColorPanel)).EndInit();
            this.ColorPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.SplitContainer ToolsandLayerAndCanvas;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer LayerAndColorPanel;
        private System.Windows.Forms.SplitContainer ColorPanel;
        private Test.ColorWheel colorWheel1;
        private Test.SavedColor savedColor1;
        private Canvas.Canvas canvas1;
        private LayerList.LayerListPanel layerListPanel1;
    }
}


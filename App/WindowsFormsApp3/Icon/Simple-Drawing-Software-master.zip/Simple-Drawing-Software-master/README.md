# Simple-Drawing-Software
Một chương trình vẽ đơn giản phục vụ cho việc vẽ tranh.

## Mục tiêu chính:
    * Cung cấp được các công cụ cơ bản như trong Paint.
    * Cung cấp chức năng chỉnh sửa file ảnh đơn giản như (flip/rotate).
    * Có thể lưu lại các state để có thể ctrl + z.
    * Có thể load texture cho brush.

    
## Mục tiêu phụ:
    * Công cụ magic wand.
    * Có thể chỉnh độ đập nhạt của brush.
    * Brush có thể có soft edge hoặc hard edge.
    * Hoạt động với wacom tablet.
    
## Hoàn thành:
    * Hoạt động theo layer như Paint Tool Sai hay Photoshop.
    * Có thể chọn màu trên color wheel
